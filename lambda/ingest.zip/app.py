import json
import uuid
import os
import boto3
from datetime import datetime

s3 = boto3.client("s3")
sqs = boto3.client("sqs")

RAW_BUCKET = os.environ["RAW_BUCKET"]
LAB_RESULTS_QUEUE_URL = os.environ["LAB_RESULTS_QUEUE_URL"]


def validate_payload(body):
    required = ["patient_id", "lab_id", "lab_name", "test_type", "test_date", "results"]
    missing = [f for f in required if f not in body]
    if missing:
        return False, f"Missing fields: {', '.join(missing)}"
    if not isinstance(body["results"], list) or len(body["results"]) == 0:
        return False, "results must be a non-empty list"
    return True, ""


def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return {"statusCode": 400, "body": json.dumps({"error": "invalid_json"})}

    ok, error = validate_payload(body)
    if not ok:
        return {"statusCode": 400, "body": json.dumps({"error": error})}

    result_id = str(uuid.uuid4())

    s3_key = f"raw/{result_id}.json"
    s3.put_object(
        Bucket=RAW_BUCKET,
        Key=s3_key,
        Body=json.dumps(body).encode("utf-8"),
        ServerSideEncryption="AES256",
        Metadata={"received_at": datetime.utcnow().isoformat()},
    )

    msg = {"result_id": result_id, "s3_key": s3_key}
    sqs.send_message(
        QueueUrl=LAB_RESULTS_QUEUE_URL,
        MessageBody=json.dumps(msg),
    )

    return {
        "statusCode": 202,
        "body": json.dumps({"result_id": result_id, "status": "QUEUED"}),
    }

