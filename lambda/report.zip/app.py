import json
import os
import boto3
from datetime import datetime
import uuid

dynamo = boto3.resource("dynamodb")
s3 = boto3.client("s3")

LAB_RESULTS_TABLE = os.environ["LAB_RESULTS_TABLE"]
ACCESS_AUDIT_TABLE = os.environ["ACCESS_AUDIT_TABLE"]
REPORTS_BUCKET = os.environ["REPORTS_BUCKET"]

lab_results_table = dynamo.Table(LAB_RESULTS_TABLE)
audit_table = dynamo.Table(ACCESS_AUDIT_TABLE)


def lambda_handler(event, context):
    # Esperamos que vengan patient_id y result_id en query params
    params = event.get("queryStringParameters") or {}
    patient_id = params.get("patient_id")
    result_id = params.get("result_id")

    if not patient_id or not result_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "patient_id and result_id are required"}),
        }

    # Buscar resultado en DynamoDB
    resp = lab_results_table.get_item(
        Key={"result_id": result_id, "patient_id": patient_id}
    )
    item = resp.get("Item")
    if not item:
        return {"statusCode": 404, "body": json.dumps({"error": "result_not_found"})}

    # Crear contenido simple de "PDF"
    content = [
        f"Lab Result Report",
        f"Result ID: {result_id}",
        f"Patient ID: {patient_id}",
        f"Test Type: {item.get('test_type')}",
        f"Test Date: {item.get('test_date')}",
        "",
        "Results:",
    ]
    for r in item.get("results", []):
        line = f"- {r.get('test_code')} {r.get('test_name')}: {r.get('value')} {r.get('unit')} (ref: {r.get('reference_range')})"
        content.append(line)

    body_bytes = "\n".join(content).encode("utf-8")

    # Guardar "PDF" en S3
    key = f"reports/{patient_id}/{result_id}.pdf"
    s3.put_object(
        Bucket=REPORTS_BUCKET,
        Key=key,
        Body=body_bytes,
        ServerSideEncryption="AES256",
        Metadata={"generated_at": datetime.utcnow().isoformat()},
    )

    # Generar URL firmada
    url = s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": REPORTS_BUCKET, "Key": key},
        ExpiresIn=3600,  # 1 hora
    )

    # Registrar en auditoría
    audit_table.put_item(
        Item={
            "audit_id": str(uuid.uuid4()),
            "action": "GENERATE_REPORT",
            "patient_id": patient_id,
            "result_id": result_id,
            "timestamp": datetime.utcnow().isoformat(),
            "reason": "patient_download",
        }
    )

    return {"statusCode": 200, "body": json.dumps({"download_url": url})}

