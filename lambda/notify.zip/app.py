import json
import os
import boto3
from datetime import datetime
import uuid

dynamo = boto3.resource("dynamodb")
sns = boto3.client("sns")

PATIENTS_TABLE = os.environ["PATIENTS_TABLE"]
ACCESS_AUDIT_TABLE = os.environ["ACCESS_AUDIT_TABLE"]
SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]

patients_table = dynamo.Table(PATIENTS_TABLE)
audit_table = dynamo.Table(ACCESS_AUDIT_TABLE)


def notify_patient(patient_id: str, result_id: str):
    # Buscar paciente en DynamoDB
    resp = patients_table.get_item(Key={"patient_id": patient_id})
    item = resp.get("Item")
    if not item:
        print(f"Paciente {patient_id} no encontrado, no se manda correo")
        return

    email = item.get("email")
    if not email:
        print(f"Paciente {patient_id} sin email registrado")
        return

    message = f"Hola {item.get('first_name', '')}, tu resultado de laboratorio {result_id} está listo en el portal."

    # Publicar mensaje en SNS (que enviará email)
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=message,
        Subject="Tus resultados de laboratorio están listos",
    )

    # Registrar en tabla de auditoría
    audit_table.put_item(
        Item={
            "audit_id": str(uuid.uuid4()),
            "action": "SEND_NOTIFICATION",
            "patient_id": patient_id,
            "result_id": result_id,
            "timestamp": datetime.utcnow().isoformat(),
            "reason": "result_ready",
        }
    )


def lambda_handler(event, context):
    # Evento SQS: lista de Records
    for record in event["Records"]:
        body = json.loads(record["body"])
        patient_id = body["patient_id"]
        result_id = body["result_id"]

        print(f"Notificando a paciente {patient_id} por resultado {result_id}")
        notify_patient(patient_id, result_id)

    return {"statusCode": 200}

